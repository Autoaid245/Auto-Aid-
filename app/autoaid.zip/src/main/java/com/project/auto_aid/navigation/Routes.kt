package com.project.auto_aid.navigation

sealed class Routes(val route: String) {
    object OnBoardScreen : Routes("onboard_screen")
    object LoginScreen : Routes("login_screen")
    object SignupScreen : Routes("signup_screen")
    object HomeScreen : Routes("home_screen")

    object ProfileScreen : Routes("profile")
}
