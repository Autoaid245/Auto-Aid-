package com.project.auto_aid.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF0A84FF)
val BlueSecondary = Color(0xFF4CB0FF)
val BackgroundLight = Color(0xFFFFFFFF)
val TextDark = Color(0xFF000000)

val SurfaceVariantLight = Color(0xFFE0ECFF) // soft blue background

