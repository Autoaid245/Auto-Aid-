package com.project.auto_aid.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.project.auto_aid.navigation.Routes

@Composable
fun ProfileScreen(navController: NavController) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    val userId = auth.currentUser?.uid

    var firstName by remember { mutableStateOf("") }
    var otherName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    LaunchedEffect(userId) {
        if (userId != null) {
            db.collection("users").document(userId).get()
                .addOnSuccessListener {
                    firstName = it.getString("firstName") ?: ""
                    otherName = it.getString("otherName") ?: ""
                    email = it.getString("email") ?: ""
                }
                .addOnFailureListener {
                    Toast.makeText(context, "Failed to load profile", Toast.LENGTH_SHORT).show()
                }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.Top
    ) {

        Text(text = "Profile", fontSize = 32.sp, color = Color.Black)

        Spacer(modifier = Modifier.height(20.dp))

        Text("First Name: $firstName", fontSize = 20.sp)
        Text("Other Name: $otherName", fontSize = 20.sp)
        Text("Email: $email", fontSize = 20.sp)
        Text("User ID: $userId", fontSize = 20.sp)

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = {
                auth.signOut()
                navController.navigate(Routes.LoginScreen.route) {
                    popUpTo(Routes.HomeScreen.route) { inclusive = true }
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Red
            )
        ) {
            Text("Logout", color = Color.White)
        }
    }
}
