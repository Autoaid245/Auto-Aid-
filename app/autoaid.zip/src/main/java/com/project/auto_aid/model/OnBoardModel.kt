package com.project.auto_aid.model



data class OnBoardModel(
    val imageRes: Int,
    val title: String,
    val description: String,
    val buttonText: String
)