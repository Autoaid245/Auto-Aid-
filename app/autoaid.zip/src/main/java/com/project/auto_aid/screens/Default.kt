package com.project.auto_aid.screens

class Default(notifications: Any, contentDescription: String) {

}
