package com.project.auto_aid.navigation

import LoginScreen
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.project.auto_aid.model.OnBoardScreen
import com.project.auto_aid.screens.HomeScreen
import com.project.auto_aid.screens.ProfileScreen
import com.project.auto_aid.screens.SignupScreen

@Composable
fun AppNavigation(navController: NavHostController, startDestination: String) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Routes.OnBoardScreen.route) {
            OnBoardScreen(navController)
        }
        composable(Routes.LoginScreen.route) {
            LoginScreen(navController)
        }
        composable(Routes.SignupScreen.route) {
            SignupScreen(navController)
        }
        composable(Routes.HomeScreen.route) {
            HomeScreen(navController)
        }
        composable("profile_screen") {
            ProfileScreen(navController)
        }

    }
}
